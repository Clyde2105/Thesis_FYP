# artbot_sim – run checklist (ROS 2 Jazzy + Gazebo Sim)

## 1) Build + source
```bash
cd ~/ros2_ws
colcon build --packages-select artbot_sim
source /opt/ros/jazzy/setup.bash
source ~/ros2_ws/install/setup.bash
```

## 2) Start the sim
```bash
ros2 launch artbot_sim sim.launch.py
```

**Wait ~5 seconds** until you see both controllers active:
```bash
ros2 control list_controllers
```
Expected:
- `joint_state_broadcaster ... active`
- `diff_drive_controller ... active`

## 3) Drive only (should visibly move)
```bash
ros2 run artbot_sim drive_square_dd.py
```

## 4) Draw square with ink dots (Gazebo trail)
```bash
ros2 run artbot_sim draw_square.py
```

If ink spawning fails (some setups block `gz service`), do:
```bash
ros2 run artbot_sim draw_square.py --no-ink
```

## 5) Quick “is it REALLY moving?” check
In another terminal while driving:
```bash
gz topic -l | grep -E "pose/info|/model/artbot"
# then echo pose info and search for base pose changes
```

### Why this version works better
- Body collision is lifted so it doesn't scrape/pin the robot.
- Paper is visual-only so it doesn't fight the ground plane collision.
- ros2_control yaml path is passed in at launch (no hardcoded /home/... path).
