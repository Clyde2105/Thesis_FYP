#!/usr/bin/env python3
import math
import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped


class DriveSquare(Node):
    def __init__(self):
        super().__init__("drive_square_dd")

        self.pub = self.create_publisher(
            TwistStamped, "/diff_drive_controller/cmd_vel", 10
        )

        # Tune these
        self.speed = 0.10          # m/s
        self.side_len = 0.40       # meters
        self.turn_speed = 1.0      # rad/s

        # Derived timings
        self.side_time = self.side_len / self.speed
        self.turn_time = (math.pi / 2.0) / self.turn_speed

        time.sleep(1.0)  # let pubs/subs connect
        self.run_square()

    def publish_cmd(self, vx: float, wz: float):
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "base_link"
        msg.twist.linear.x = float(vx)
        msg.twist.angular.z = float(wz)
        self.pub.publish(msg)

    def run_for(self, vx: float, wz: float, duration: float):
        end = time.time() + duration
        while rclpy.ok() and time.time() < end:
            self.publish_cmd(vx, wz)
            rclpy.spin_once(self, timeout_sec=0.0)
            time.sleep(0.05)

    def run_square(self):
        self.get_logger().info("Driving a square...")

        for _ in range(4):
            self.run_for(self.speed, 0.0, self.side_time)      # forward
            self.run_for(0.0, self.turn_speed, self.turn_time) # 90 deg turn

        # stop
        self.run_for(0.0, 0.0, 0.2)
        self.get_logger().info("Done.")


def main():
    rclpy.init()
    node = DriveSquare()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
