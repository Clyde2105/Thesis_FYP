#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from gazebo_msgs.srv import SpawnEntity
from tf2_ros import TransformListener, Buffer
import math

# The SDF model for a single dot of ink (No collision, Static, Red)
INK_SDF = """
<sdf version='1.6'>
  <model name='ink_dot'>
    <static>true</static>
    <link name='link'>
      <visual name='visual'>
        <geometry>
          <cylinder>
            <radius>0.005</radius> <length>0.001</length> </cylinder>
        </geometry>
        <material>
          <ambient>1 0 0 1</ambient> <diffuse>1 0 0 1</diffuse>
        </material>
      </visual>
    </link>
  </model>
</sdf>
"""

class InkSpawner(Node):
    def __init__(self):
        super().__init__('ink_spawner')
        
        # Create client to spawn objects in Gazebo
        self.client = self.create_client(SpawnEntity, '/spawn_entity')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /spawn_entity service...')

        # TF Setup to track robot tip
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # State
        self.last_x = 0.0
        self.last_y = 0.0
        self.dot_count = 0
        self.draw_threshold = 0.01 # Spawn a dot every 1cm of movement
        
        # Timer (Check position every 0.1s)
        self.timer = self.create_timer(0.1, self.check_and_draw)

    def check_and_draw(self):
        try:
            # CHANGE 'tool0' to your robot's actual end-effector link name!
            t = self.tf_buffer.lookup_transform('world', 'tool0', rclpy.time.Time())
            
            x = t.transform.translation.x
            y = t.transform.translation.y
            z = t.transform.translation.z

            # LOGIC:
            # 1. Height check: Is the pen touching the paper? (Assume paper is at Z=0.0)
            # 2. Distance check: Has it moved enough to spawn a new dot?
            if z < 0.05: # Adjust based on your table height
                dist = math.sqrt((x - self.last_x)**2 + (y - self.last_y)**2)
                
                if dist > self.draw_threshold:
                    self.spawn_ink(x, y, 0.001) # Spawn slightly above ground to avoid z-fighting
                    self.last_x = x
                    self.last_y = y

        except Exception as e:
            pass

    def spawn_ink(self, x, y, z):
        request = SpawnEntity.Request()
        request.name = f'ink_dot_{self.dot_count}' # Unique name required
        request.xml = INK_SDF
        request.initial_pose.position.x = x
        request.initial_pose.position.y = y
        request.initial_pose.position.z = z
        
        self.dot_count += 1
        self.client.call_async(request)

def main(args=None):
    rclpy.init(args=args)
    node = InkSpawner()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()