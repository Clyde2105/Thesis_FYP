#!/usr/bin/env python3
"""
Drive a clean square using odometry feedback (works in VM / slow sim too).

Key fixes:
- Publishes to BOTH cmd_vel (TwistStamped) and cmd_vel_unstamped (Twist)
  so it works regardless of diff_drive_controller.use_stamped_vel.
- Waypoint-based square: (L,0)->(L,L)->(0,L)->(0,0) relative to start,
  so it actually closes the loop.
"""

import math
import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from geometry_msgs.msg import Twist, TwistStamped
from nav_msgs.msg import Odometry


def yaw_from_quat(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def wrap_pi(a: float) -> float:
    while a > math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


class DriveSquare(Node):
    def __init__(self):
        super().__init__("drive_square_dd")

        # Use Gazebo /clock
        self.set_parameters([Parameter("use_sim_time", Parameter.Type.BOOL, True)])

        # --- Tunables ---
        self.side_len = 0.40          # meters
        self.dist_tol = 0.02          # meters (corner tolerance)
        self.yaw_tol = 0.02           # rad (~1.1 deg)

        self.v_max = 0.10             # m/s
        self.w_max = 1.20             # rad/s

        self.k_heading = 3.0          # heading P gain
        self.k_yaw = 2.5              # turn-to-yaw P gain

        # Publish to BOTH (stamped + unstamped) so controller config doesn't matter
        self.pub_stamped = self.create_publisher(TwistStamped, "/diff_drive_controller/cmd_vel", 10)
        self.pub_unstamped = self.create_publisher(Twist, "/diff_drive_controller/cmd_vel_unstamped", 10)

        self.sub = self.create_subscription(Odometry, "/diff_drive_controller/odom", self.on_odom, 10)

        self.odom = None
        self.state = "WAIT_ODOM"   # WAIT_ODOM -> ALIGN -> GO -> TURN -> DONE
        self.corner_idx = 0

        self.x0 = 0.0
        self.y0 = 0.0
        self.yaw0 = 0.0

        self.targets = []          # list of (x,y) world corners
        self.turn_targets = []     # list of yaw targets per side

        self.timer = self.create_timer(0.05, self.update)  # 20 Hz
        self.get_logger().info("DriveSquare ready (odom-waypoint).")

    def on_odom(self, msg: Odometry):
        self.odom = msg

    def cmd(self, vx: float, wz: float):
        # Unstamped
        tu = Twist()
        tu.linear.x = float(vx)
        tu.angular.z = float(wz)
        self.pub_unstamped.publish(tu)

        # Stamped
        ts = TwistStamped()
        ts.header.stamp = self.get_clock().now().to_msg()
        ts.header.frame_id = "base_link"
        ts.twist.linear.x = float(vx)
        ts.twist.angular.z = float(wz)
        self.pub_stamped.publish(ts)

    def stop(self):
        self.cmd(0.0, 0.0)

    def build_square_targets(self):
        # Square corners in *start frame* then rotate into world by yaw0
        L = self.side_len
        local = [(L, 0.0), (L, L), (0.0, L), (0.0, 0.0)]

        cy = math.cos(self.yaw0)
        sy = math.sin(self.yaw0)

        self.targets = []
        for lx, ly in local:
            wx = self.x0 + (lx * cy - ly * sy)
            wy = self.y0 + (lx * sy + ly * cy)
            self.targets.append((wx, wy))

        self.turn_targets = [
            wrap_pi(self.yaw0 + 0.0),
            wrap_pi(self.yaw0 + math.pi / 2.0),
            wrap_pi(self.yaw0 + math.pi),
            wrap_pi(self.yaw0 - math.pi / 2.0),
            wrap_pi(self.yaw0 + 0.0),
        ]

    def update(self):
        if self.odom is None:
            return

        x = self.odom.pose.pose.position.x
        y = self.odom.pose.pose.position.y
        yaw = yaw_from_quat(self.odom.pose.pose.orientation)

        if self.state == "WAIT_ODOM":
            self.x0, self.y0 = x, y

            # Snap yaw to nearest 90deg so it starts axis-aligned
            snapped = round(yaw / (math.pi / 2.0)) * (math.pi / 2.0)
            self.yaw0 = wrap_pi(snapped)

            self.build_square_targets()
            self.state = "ALIGN"
            self.get_logger().info(f"Start=({self.x0:.3f},{self.y0:.3f}) yaw={yaw:.3f} -> yaw0={self.yaw0:.3f}")
            return

        if self.state == "ALIGN":
            e = wrap_pi(self.yaw0 - yaw)
            if abs(e) <= self.yaw_tol:
                self.stop()
                self.state = "GO"
                self.corner_idx = 0
                self.get_logger().info("Aligned. Driving square...")
            else:
                wz = clamp(self.k_yaw * e, -self.w_max, self.w_max)
                self.cmd(0.0, wz)
            return

        if self.state == "GO":
            tx, ty = self.targets[self.corner_idx]
            dx = tx - x
            dy = ty - y
            dist = math.hypot(dx, dy)

            if dist <= self.dist_tol:
                self.stop()
                self.get_logger().info(f"Reached corner {self.corner_idx+1}/4 (dist={dist:.3f}).")
                self.state = "TURN"
                return

            desired = math.atan2(dy, dx)
            e_head = wrap_pi(desired - yaw)

            # Slow down if we're facing away, so it doesn't “arc” corners
            facing = max(0.0, math.cos(e_head))
            v = clamp(self.v_max * facing, 0.03, self.v_max)
            w = clamp(self.k_heading * e_head, -self.w_max, self.w_max)

            self.cmd(v, w)
            return

        if self.state == "TURN":
            # Turn to the next side's axis yaw (hard 90deg)
            target_yaw = self.turn_targets[self.corner_idx + 1]
            e = wrap_pi(target_yaw - yaw)

            if abs(e) <= self.yaw_tol:
                self.stop()
                self.corner_idx += 1
                if self.corner_idx >= 4:
                    self.state = "DONE"
                    self.get_logger().info("Done.")
                else:
                    self.state = "GO"
                    self.get_logger().info(f"Turning complete. Next yaw={target_yaw:.3f}")
            else:
                wz = clamp(self.k_yaw * e, -self.w_max, self.w_max)
                self.cmd(0.0, wz)
            return

        if self.state == "DONE":
            self.stop()
            return


def main():
    rclpy.init()
    node = DriveSquare()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
