#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
import time

# --- CONFIGURATION ---
# 1. Update with your robot's joint names (check your URDF or /joint_states)
JOINT_NAMES = ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

# 2. Hardcode the 4 corners of the square (Joint angles in Radians)
# Move your robot to the corner in Gazebo, echo /joint_states, and copy values here.
CORNER_1 = [0.0, -1.57, 1.57, 0.0, 0.0, 0.0] 
CORNER_2 = [0.2, -1.57, 1.57, 0.0, 0.0, 0.0]
CORNER_3 = [0.2, -1.40, 1.40, 0.0, 0.0, 0.0]
CORNER_4 = [0.0, -1.40, 1.40, 0.0, 0.0, 0.0]
# ---------------------

class SquareDrawer(Node):
    def __init__(self):
        super().__init__('square_drawer')
        # Standard ROS2 Control topic
        self.publisher_ = self.create_publisher(JointTrajectory, '/joint_trajectory_controller/joint_trajectory', 10)
        time.sleep(1) # Wait for connection
        self.send_square_trajectory()

    def send_square_trajectory(self):
        msg = JointTrajectory()
        msg.joint_names = JOINT_NAMES
        
        points = [CORNER_1, CORNER_2, CORNER_3, CORNER_4, CORNER_1] # Close the loop
        
        time_from_start = 2 # Seconds per move
        
        for i, p in enumerate(points):
            point = JointTrajectoryPoint()
            point.positions = p
            point.time_from_start.sec = time_from_start * (i + 1)
            msg.points.append(point)
            
        self.get_logger().info('Publishing Square Trajectory...')
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = SquareDrawer()
    rclpy.spin_once(node, timeout_sec=2)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()