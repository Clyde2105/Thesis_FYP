#!/usr/bin/env python3
"""
Drop 'ink' dots in Gazebo as the robot moves.

Fixes:
- Unique names per run so dots never collide with previous runs.
- Inline SDF sphere (no dependency on models/ink_spot.sdf paths).
"""

import math
import os
import time
import tempfile
import subprocess

import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from nav_msgs.msg import Odometry


class InkSpawner(Node):
    def __init__(self):
        super().__init__("ink_spawner")

        self.set_parameters([Parameter("use_sim_time", Parameter.Type.BOOL, True)])

        # --- knobs ---
        self.world = self.declare_parameter("world", "art_world").value
        self.drop_dist = float(self.declare_parameter("drop_dist", 0.02).value)   # meters
        self.z = float(self.declare_parameter("ink_z", 0.011).value)              # meters
        self.radius = float(self.declare_parameter("ink_radius", 0.008).value)

        self.prefix = f"ink_{int(time.time() * 1000)}_"
        self.counter = 0

        self.last_xy = None
        self.odom = None

        self.sub = self.create_subscription(Odometry, "/diff_drive_controller/odom", self.on_odom, 10)
        self.timer = self.create_timer(0.05, self.update)  # 20 Hz

        self.get_logger().info(
            f"Ink spawner ready (ros_gz). Dots every ~{self.drop_dist:.3f} m in world '{self.world}'. Prefix: {self.prefix}"
        )

    def on_odom(self, msg: Odometry):
        self.odom = msg

    def update(self):
        if self.odom is None:
            return

        x = self.odom.pose.pose.position.x
        y = self.odom.pose.pose.position.y

        if self.last_xy is None:
            self._spawn_dot(x, y)
            self.last_xy = (x, y)
            return

        dx = x - self.last_xy[0]
        dy = y - self.last_xy[1]
        dist = math.hypot(dx, dy)

        if dist >= self.drop_dist:
            self._spawn_dot(x, y)
            self.last_xy = (x, y)

    def _spawn_dot(self, x: float, y: float):
        name = f"{self.prefix}{self.counter:05d}"
        self.counter += 1

        # Small red sphere
        sdf = f"""<sdf version="1.7">
  <model name="{name}">
    <static>true</static>
    <link name="link">
      <visual name="visual">
        <geometry>
          <sphere><radius>{self.radius}</radius></sphere>
        </geometry>
        <material>
          <ambient>1 0 0 1</ambient>
          <diffuse>1 0 0 1</diffuse>
        </material>
      </visual>
    </link>
  </model>
</sdf>
"""

        req = f"""
name: "{name}"
sdf: "{sdf.replace('"', '\\"').replace("\\n", "")}"
pose {{
  position {{ x: {x:.6f} y: {y:.6f} z: {self.z:.6f} }}
}}
"""

        try:
            with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".req") as f:
                f.write(req)
                req_file = f.name

            cmd = [
                "gz", "service",
                "-s", f"/world/{self.world}/create",
                "--reqtype", "gz.msgs.EntityFactory",
                "--reptype", "gz.msgs.Boolean",
                "--timeout", "1000",
                "--req-file", req_file,
            ]

            res = subprocess.run(cmd, capture_output=True, text=True)
            if res.returncode != 0:
                self.get_logger().warn(
                    f"Failed to spawn dot '{name}' (rc={res.returncode}). stderr:\n{res.stderr.strip()}"
                )

        except Exception as e:
            self.get_logger().warn(f"Exception while spawning dot '{name}': {e}")

        finally:
            try:
                os.remove(req_file)
            except Exception:
                pass


def main():
    rclpy.init()
    node = InkSpawner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
